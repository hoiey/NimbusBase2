/** Automatically generated file. DO NOT MODIFY */
package com.example.nimbusbase_android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}